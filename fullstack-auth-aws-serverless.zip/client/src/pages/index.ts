export { default as AuthPage } from "./AuthPage";
export { default as ProfilePage } from "./ProfilePage";
