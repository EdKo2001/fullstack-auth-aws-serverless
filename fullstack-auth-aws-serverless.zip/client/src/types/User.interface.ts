interface User {
  email: string;
  name: string;
  profileImage?: string;
}

export default User;
