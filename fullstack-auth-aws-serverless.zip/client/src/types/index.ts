export type { default as User } from "./User.interface";
